import { useState, useEffect, useRef } from "react";

// ─── SHA-256 password hashing ─────────────────────────────────────────────────
async function hashPassword(pass) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(pass + "privatechat_salt_v2"));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,"0")).join("");
}

// ─── BroadcastChannel for real-time sync across tabs ─────────────────────────
const bc = typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("privatechat") : null;

// ─── Storage helpers (localStorage) ─────────────────────────────────────────
const store = {
  get: (key) => { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch { return null; } },
  set: (key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); bc?.postMessage({ type:"update", key }); } catch {} },
  delete: (key) => { try { localStorage.removeItem(key); } catch {} },
  keys: (prefix) => Object.keys(localStorage).filter(k => k.startsWith(prefix)),
};

// ─── Theme ────────────────────────────────────────────────────────────────────
const C = {
  bg:"#0b0f1a", surface:"#111827", card:"#161e2e", accent:"#6c63ff",
  accentDim:"#6c63ff22", text:"#e8edf5", textMuted:"#8899aa",
  border:"#1e2d42", sent:"#1a1040", received:"#161e2e",
  online:"#22d3a5", danger:"#ff4757", admin:"#f59e0b",
};
const FONT = "'DM Sans',sans-serif";
const ROOMS = [
  {id:"general",name:"General",icon:"🌐"},
  {id:"announcements",name:"Announcements",icon:"📢"},
  {id:"random",name:"Random",icon:"🎲"},
];
const EMOJIS = ["👍","❤️","😂","😮","😢","🔥","🎉","👏","🙏","💯"];

const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
html,body,#root{height:100%;overflow:hidden}
body{background:${C.bg};font-family:${FONT};color:${C.text}}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:${C.border};border-radius:2px}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes dot{0%,80%,100%{transform:scale(.6);opacity:.4}40%{transform:scale(1);opacity:1}}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
@keyframes recPulse{0%,100%{box-shadow:0 0 0 0 rgba(255,71,87,.5)}50%{box-shadow:0 0 0 8px rgba(255,71,87,0)}}
.fadeUp{animation:fadeUp .2s ease}
.shake{animation:shake .35s ease}
.hover-actions{opacity:0;transition:opacity .15s}
.msg-wrap:hover .hover-actions{opacity:1}
@media(max-width:600px){
  .sidebar{width:100%!important;position:absolute!important;z-index:10!important;height:100%!important}
  .sidebar.hidden{display:none!important}
  .main{width:100%!important}
}
`;

// ─── Avatar ───────────────────────────────────────────────────────────────────
function Avatar({name, size=38, online=false, isAdmin=false}) {
  const initials = name.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2);
  const hue = name.split("").reduce((a,c)=>a+c.charCodeAt(0),0) % 360;
  return (
    <div style={{position:"relative",flexShrink:0}}>
      <div style={{width:size,height:size,borderRadius:"50%",background:`hsl(${hue},50%,35%)`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Space Grotesk',sans-serif",fontSize:size*.35,fontWeight:700,color:"#fff",border:`2px solid ${isAdmin?C.admin:C.border}`}}>
        {initials}
      </div>
      {online && <div style={{position:"absolute",bottom:1,right:1,width:size*.28,height:size*.28,borderRadius:"50%",background:C.online,border:`2px solid ${C.surface}`}}/>}
      {isAdmin && <div style={{position:"absolute",top:-3,right:-3,fontSize:9,background:C.admin,borderRadius:4,padding:"1px 3px",color:"#000",fontWeight:700,lineHeight:1}}>A</div>}
    </div>
  );
}

// ─── Voice Player ─────────────────────────────────────────────────────────────
function VoicePlayer({src}) {
  const [playing, setPlaying] = useState(false);
  const [prog, setProg] = useState(0);
  const [dur, setDur] = useState(0);
  const aRef = useRef(null);
  useEffect(() => {
    const a = new Audio(src);
    aRef.current = a;
    a.onloadedmetadata = () => setDur(a.duration);
    a.ontimeupdate = () => setProg(a.duration ? a.currentTime/a.duration : 0);
    a.onended = () => { setPlaying(false); setProg(0); };
    return () => a.pause();
  }, [src]);
  const toggle = () => { const a = aRef.current; if(playing){a.pause();setPlaying(false);}else{a.play();setPlaying(true);} };
  const fmt = s => s ? `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}` : "0:00";
  return (
    <div style={{display:"flex",alignItems:"center",gap:8,minWidth:180}}>
      <button onClick={toggle} style={{width:32,height:32,borderRadius:"50%",background:C.accent,border:"none",color:"#fff",fontSize:13,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>{playing?"⏸":"▶"}</button>
      <div style={{flex:1}}>
        <div style={{height:4,background:C.border,borderRadius:2,marginBottom:4}}>
          <div style={{width:`${prog*100}%`,height:"100%",background:C.accent,borderRadius:2,transition:"width .1s"}}/>
        </div>
        <div style={{fontSize:10,color:C.textMuted}}>🎤 {fmt(dur)}</div>
      </div>
    </div>
  );
}

// ─── Voice Recorder ───────────────────────────────────────────────────────────
function useVoiceRecorder(onDone) {
  const [recording, setRecording] = useState(false);
  const [secs, setSecs] = useState(0);
  const mrRef = useRef(null);
  const timerRef = useRef(null);
  const chunksRef = useRef([]);
  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({audio:true});
      chunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mr.ondataavailable = e => chunksRef.current.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, {type:"audio/webm"});
        const reader = new FileReader();
        reader.onload = () => onDone(reader.result);
        reader.readAsDataURL(blob);
        stream.getTracks().forEach(t=>t.stop());
      };
      mr.start(); mrRef.current = mr;
      setRecording(true); setSecs(0);
      timerRef.current = setInterval(() => setSecs(s=>s+1), 1000);
    } catch { alert("Microphone access denied"); }
  };
  const stop = () => { mrRef.current?.stop(); clearInterval(timerRef.current); setRecording(false); setSecs(0); };
  return {recording, secs, start, stop};
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("auth");
  const [authMode, setAuthMode] = useState("login");
  const [form, setForm] = useState({username:"",password:"",confirm:""});
  const [formErr, setFormErr] = useState("");
  const [shake, setShake] = useState(false);
  const [user, setUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("pc_session")); } catch { return null; }
  });

  const [activeTab, setActiveTab] = useState("rooms");
  const [activeRoom, setActiveRoom] = useState("general");
  const [activeDM, setActiveDM] = useState(null);
  const [allMsgs, setAllMsgs] = useState({});
  const [input, setInput] = useState("");
  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState("");
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [emojiFor, setEmojiFor] = useState(null);
  const [dmSearch, setDmSearch] = useState("");
  const [adminTab, setAdminTab] = useState("users");
  const [showSidebar, setShowSidebar] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 600);
  const endRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const s = document.createElement("style");
    s.textContent = GLOBAL_CSS;
    document.head.appendChild(s);
    const handleResize = () => setIsMobile(window.innerWidth <= 600);
    window.addEventListener("resize", handleResize);
    return () => { document.head.removeChild(s); window.removeEventListener("resize", handleResize); };
  }, []);

  // Resume session
  useEffect(() => {
    if (user) setScreen("chat");
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({behavior:"smooth"}); }, [allMsgs, activeRoom, activeDM]);

  // Load all data
  const loadAll = () => {
    const msgs = {};
    for (const r of ROOMS) {
      msgs[`msgs:${r.id}`] = store.get(`msgs:${r.id}`) || [];
    }
    store.keys("msgs:dm:").forEach(key => { msgs[key] = store.get(key) || []; });
    setAllMsgs(msgs);
    setAllUsers(Object.values(store.get("db:users") || {}));

    // Online heartbeat
    const ol = store.get("chat:online") || [];
    const fresh = ol.filter(u => Date.now() - u.ts < 20000);
    if (user) {
      const updated = [...fresh.filter(u => u.name !== user?.username), {name: user?.username, ts: Date.now()}];
      store.set("chat:online", updated);
      setOnlineUsers(updated);
    } else {
      setOnlineUsers(fresh);
    }
  };

  useEffect(() => {
    if (screen === "auth") return;
    loadAll();
    const t = setInterval(loadAll, 3000);
    // BroadcastChannel for instant cross-tab sync
    if (bc) bc.onmessage = () => loadAll();
    return () => { clearInterval(t); if(bc) bc.onmessage = null; };
  }, [screen, user]);

  const triggerShake = (msg) => { setFormErr(msg); setShake(true); setTimeout(()=>setShake(false), 400); };

  const handleAuth = async () => {
    setFormErr("");
    const {username, password, confirm} = form;
    if (!username.trim() || !password) return triggerShake("Please fill all fields");
    let db = store.get("db:users") || {};
    if (authMode === "register") {
      if (password !== confirm) return triggerShake("Passwords don't match");
      if (password.length < 4) return triggerShake("Password min 4 characters");
      if (db[username.toLowerCase()]) return triggerShake("Username already taken");
      const hashed = await hashPassword(password);
      const isFirst = Object.keys(db).length === 0;
      db[username.toLowerCase()] = {username, hashed, isAdmin:isFirst, createdAt:Date.now(), lastSeen:Date.now()};
      store.set("db:users", db);
      const u = db[username.toLowerCase()];
      sessionStorage.setItem("pc_session", JSON.stringify(u));
      setUser(u); setScreen("chat");
    } else {
      const u = db[username.toLowerCase()];
      if (!u) return triggerShake("User not found");
      const hashed = await hashPassword(password);
      if (hashed !== u.hashed) return triggerShake("Incorrect password");
      u.lastSeen = Date.now(); db[username.toLowerCase()] = u;
      store.set("db:users", db);
      sessionStorage.setItem("pc_session", JSON.stringify(u));
      setUser(u); setScreen("chat");
    }
  };

  const dmKey = (a,b) => `msgs:dm:${[a,b].sort().join("__")}`;
  const activeKey = activeTab==="dms" && activeDM ? dmKey(user?.username, activeDM) : `msgs:${activeRoom}`;
  const curMsgs = allMsgs[activeKey] || [];

  const saveMsgs = (key, msgs) => {
    const sliced = msgs.slice(-200);
    store.set(key, sliced);
    setAllMsgs(p => ({...p, [key]: sliced}));
  };

  const sendMsg = async (voiceData) => {
    const text = voiceData ? null : input.trim();
    if (!voiceData && !text) return;
    setInput("");
    const msg = {id:`${Date.now()}_${Math.random().toString(36).slice(2)}`,sender:user.username,text:text||null,voice:voiceData||null,ts:Date.now(),edited:false,reactions:{},deleted:false};
    saveMsgs(activeKey, [...curMsgs, msg]);
    inputRef.current?.focus();
  };

  const deleteMsg = (id) => saveMsgs(activeKey, curMsgs.map(m => m.id===id ? {...m,deleted:true,text:null,voice:null} : m));

  const saveEdit = (id) => {
    if (!editText.trim()) return;
    saveMsgs(activeKey, curMsgs.map(m => m.id===id ? {...m,text:editText.trim(),edited:true} : m));
    setEditId(null);
  };

  const addReaction = (id, emoji) => {
    saveMsgs(activeKey, curMsgs.map(m => {
      if (m.id !== id) return m;
      const r = {...m.reactions};
      if (!r[emoji]) r[emoji] = [];
      if (r[emoji].includes(user.username)) { r[emoji]=r[emoji].filter(u=>u!==user.username); if(!r[emoji].length) delete r[emoji]; }
      else r[emoji] = [...r[emoji], user.username];
      return {...m, reactions:r};
    }));
    setEmojiFor(null);
  };

  const adminDeleteUser = (uname) => {
    if (!window.confirm(`Delete user "${uname}"?`)) return;
    const db = store.get("db:users") || {};
    delete db[uname.toLowerCase()];
    store.set("db:users", db);
    setAllUsers(Object.values(db));
  };

  const adminDeleteMsg = (key, id) => {
    saveMsgs(key, (allMsgs[key]||[]).map(m => m.id===id ? {...m,deleted:true,text:null,voice:null} : m));
  };

  const logout = () => { sessionStorage.removeItem("pc_session"); setUser(null); setScreen("auth"); };

  const {recording, secs, start:startRec, stop:stopRec} = useVoiceRecorder(sendMsg);
  const onlineNow = onlineUsers.filter(u => Date.now()-u.ts < 20000);

  // ─── AUTH SCREEN ──────────────────────────────────────────────────────────
  if (screen === "auth") {
    return (
      <div style={{height:"100%",display:"flex",alignItems:"center",justifyContent:"center",background:C.bg,padding:20,overflow:"auto"}}>
        <div className={shake?"shake":""} style={{width:"100%",maxWidth:380,background:C.surface,borderRadius:24,border:`1px solid ${C.border}`,padding:36,boxShadow:"0 24px 64px rgba(0,0,0,.6)"}}>
          <div style={{textAlign:"center",marginBottom:28}}>
            <div style={{fontSize:44,marginBottom:8}}>🔐</div>
            <h1 style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:26,fontWeight:700}}>PrivateChat</h1>
            <p style={{color:C.textMuted,fontSize:13,marginTop:4}}>Secure · Private · Encrypted</p>
          </div>
          <div style={{display:"flex",background:C.card,borderRadius:12,padding:3,marginBottom:22}}>
            {["login","register"].map(m => (
              <button key={m} onClick={()=>{setAuthMode(m);setFormErr("");}} style={{flex:1,padding:"9px 0",borderRadius:10,border:"none",background:authMode===m?C.accent:"transparent",color:authMode===m?"#fff":C.textMuted,fontFamily:"'Space Grotesk',sans-serif",fontWeight:600,fontSize:13,cursor:"pointer",transition:"all .2s"}}>
                {m==="login"?"Sign In":"Register"}
              </button>
            ))}
          </div>
          {["username","password",...(authMode==="register"?["confirm"]:[])].map(f => (
            <input key={f} type={f==="username"?"text":"password"}
              placeholder={f==="confirm"?"Confirm password":f.charAt(0).toUpperCase()+f.slice(1)}
              value={form[f]} onChange={e=>setForm(p=>({...p,[f]:e.target.value}))}
              onKeyDown={e=>e.key==="Enter"&&handleAuth()}
              style={{width:"100%",padding:"12px 16px",borderRadius:10,marginBottom:10,background:C.card,border:`1px solid ${formErr?C.danger:C.border}`,color:C.text,fontSize:14,outline:"none",fontFamily:FONT,display:"block"}}
            />
          ))}
          {formErr && <p style={{color:C.danger,fontSize:13,marginBottom:10,textAlign:"center"}}>{formErr}</p>}
          <button onClick={handleAuth} style={{width:"100%",padding:"13px",borderRadius:12,border:"none",background:C.accent,color:"#fff",fontFamily:"'Space Grotesk',sans-serif",fontWeight:700,fontSize:15,cursor:"pointer"}}>
            {authMode==="login"?"Sign In →":"Create Account →"}
          </button>
          <p style={{textAlign:"center",fontSize:11,color:C.textMuted,marginTop:14}}>🔒 SHA-256 encrypted · First account = Admin</p>
        </div>
      </div>
    );
  }

  // ─── ADMIN SCREEN ─────────────────────────────────────────────────────────
  if (screen === "admin") {
    const allRoomKeys = [...ROOMS.map(r=>`msgs:${r.id}`), ...Object.keys(allMsgs).filter(k=>k.startsWith("msgs:dm:"))];
    const totalMsgs = Object.values(allMsgs).flat().filter(m=>!m.deleted).length;
    const voiceMsgs = Object.values(allMsgs).flat().filter(m=>m.voice&&!m.deleted).length;
    return (
      <div style={{height:"100%",display:"flex",background:C.bg}}>
        <div style={{width:200,background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",flexShrink:0}}>
          <div style={{padding:"18px 14px",borderBottom:`1px solid ${C.border}`}}>
            <div style={{fontSize:18,marginBottom:2}}>🛡️ Admin</div>
            <div style={{fontSize:12,color:C.admin}}>{user?.username}</div>
          </div>
          {["users","messages","stats"].map(t => (
            <div key={t} onClick={()=>setAdminTab(t)} style={{padding:"12px 14px",cursor:"pointer",fontSize:14,background:adminTab===t?C.accentDim:"transparent",color:adminTab===t?C.accent:C.text,borderLeft:adminTab===t?`3px solid ${C.accent}`:"3px solid transparent"}}>
              {t==="users"?"👥 Users":t==="messages"?"💬 Messages":"📊 Stats"}
            </div>
          ))}
          <div style={{flex:1}}/>
          <div onClick={()=>setScreen("chat")} style={{padding:"12px 14px",cursor:"pointer",fontSize:14,color:C.accent,borderTop:`1px solid ${C.border}`}}>← Back to Chat</div>
          <div onClick={logout} style={{padding:"12px 14px",cursor:"pointer",fontSize:14,color:C.danger}}>🚪 Logout</div>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:24}}>
          {adminTab==="users" && (
            <div>
              <h2 style={{fontFamily:"'Space Grotesk',sans-serif",marginBottom:18}}>Users ({allUsers.length})</h2>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:10}}>
                {allUsers.map(u => (
                  <div key={u.username} style={{background:C.card,borderRadius:12,padding:14,border:`1px solid ${u.isAdmin?C.admin+"55":C.border}`}}>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                      <Avatar name={u.username} size={36} online={onlineNow.some(o=>o.name===u.username)} isAdmin={u.isAdmin}/>
                      <div>
                        <div style={{fontWeight:600,fontSize:13}}>{u.username}</div>
                        <div style={{fontSize:11,color:u.isAdmin?C.admin:C.textMuted}}>{u.isAdmin?"⭐ Admin":"User"}</div>
                      </div>
                    </div>
                    <div style={{fontSize:11,color:C.textMuted,marginBottom:10}}>
                      Joined: {new Date(u.createdAt).toLocaleDateString()}<br/>Last: {new Date(u.lastSeen).toLocaleString()}
                    </div>
                    {!u.isAdmin && u.username!==user?.username && (
                      <button onClick={()=>adminDeleteUser(u.username)} style={{padding:"5px 10px",borderRadius:7,border:"none",background:C.danger+"33",color:C.danger,fontSize:12,cursor:"pointer"}}>Delete</button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          {adminTab==="messages" && (
            <div>
              <h2 style={{fontFamily:"'Space Grotesk',sans-serif",marginBottom:18}}>All Messages</h2>
              {allRoomKeys.map(key => {
                const msgs = (allMsgs[key]||[]).filter(m=>!m.deleted);
                if (!msgs.length) return null;
                const label = key.startsWith("msgs:dm:") ? `DM: ${key.replace("msgs:dm:","").replace("__"," ↔ ")}` : `# ${key.replace("msgs:","")}`;
                return (
                  <div key={key} style={{marginBottom:20}}>
                    <div style={{fontSize:11,color:C.textMuted,marginBottom:6,fontWeight:600,textTransform:"uppercase",letterSpacing:.5}}>{label} ({msgs.length})</div>
                    {msgs.map(m => (
                      <div key={m.id} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",background:C.card,borderRadius:8,marginBottom:3,border:`1px solid ${C.border}`}}>
                        <Avatar name={m.sender} size={24}/>
                        <div style={{flex:1}}>
                          <span style={{fontWeight:600,fontSize:12,color:C.accent}}>{m.sender}</span>
                          <span style={{fontSize:10,color:C.textMuted,marginLeft:8}}>{new Date(m.ts).toLocaleString()}</span>
                          <div style={{fontSize:13,marginTop:1}}>{m.voice?"🎤 Voice":m.text}</div>
                        </div>
                        <button onClick={()=>adminDeleteMsg(key,m.id)} style={{padding:"3px 8px",borderRadius:6,border:"none",background:C.danger+"33",color:C.danger,fontSize:11,cursor:"pointer"}}>🗑</button>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          )}
          {adminTab==="stats" && (
            <div>
              <h2 style={{fontFamily:"'Space Grotesk',sans-serif",marginBottom:18}}>Statistics</h2>
              <div style={{display:"flex",flexWrap:"wrap",gap:10}}>
                {[["Total Users",allUsers.length,"👥"],["Online Now",onlineNow.length,"🟢"],["Total Messages",totalMsgs,"💬"],["Voice Messages",voiceMsgs,"🎤"]].map(([label,val,icon]) => (
                  <div key={label} style={{background:C.card,borderRadius:12,padding:"18px 24px",border:`1px solid ${C.border}`,textAlign:"center",minWidth:130}}>
                    <div style={{fontSize:28}}>{icon}</div>
                    <div style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:32,fontWeight:700,color:C.accent}}>{val}</div>
                    <div style={{fontSize:12,color:C.textMuted}}>{label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ─── CHAT SCREEN ──────────────────────────────────────────────────────────
  const otherUsers = allUsers.filter(u => u.username !== user?.username);
  const filteredDMs = otherUsers.filter(u => u.username.toLowerCase().includes(dmSearch.toLowerCase()));
  const sidebarHidden = isMobile && !showSidebar;

  return (
    <div style={{height:"100%",display:"flex",background:C.bg,overflow:"hidden",position:"relative"}} onClick={()=>setEmojiFor(null)}>
      {/* Sidebar */}
      <div className={`sidebar${sidebarHidden?" hidden":""}`} style={{width:isMobile?"100%":268,background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",flexShrink:0}}>
        <div style={{padding:"14px 12px",borderBottom:`1px solid ${C.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <Avatar name={user?.username||""} size={36} online isAdmin={user?.isAdmin}/>
            <div style={{flex:1}}>
              <div style={{fontWeight:600,fontSize:13}}>{user?.username}</div>
              <div style={{fontSize:11,color:C.online}}>● Online</div>
            </div>
            {user?.isAdmin && (
              <button onClick={()=>setScreen("admin")} style={{padding:"5px 9px",borderRadius:7,border:`1px solid ${C.admin}55`,background:C.admin+"22",color:C.admin,fontSize:11,cursor:"pointer",fontWeight:600}}>🛡️</button>
            )}
          </div>
        </div>
        <div style={{display:"flex",borderBottom:`1px solid ${C.border}`}}>
          {["rooms","dms"].map(t => (
            <button key={t} onClick={()=>setActiveTab(t)} style={{flex:1,padding:"10px 0",border:"none",background:activeTab===t?C.accentDim:"transparent",color:activeTab===t?C.accent:C.textMuted,fontFamily:"'Space Grotesk',sans-serif",fontWeight:600,fontSize:12,cursor:"pointer",borderBottom:activeTab===t?`2px solid ${C.accent}`:"2px solid transparent"}}>
              {t==="rooms"?"🌐 Rooms":"💬 DMs"}
            </button>
          ))}
        </div>
        <div style={{flex:1,overflowY:"auto",padding:"6px 6px"}}>
          {activeTab==="rooms" ? ROOMS.map(room => {
            const msgs = (allMsgs[`msgs:${room.id}`]||[]).filter(m=>!m.deleted);
            const last = msgs.slice(-1)[0];
            const isActive = activeRoom===room.id && activeTab==="rooms";
            return (
              <div key={room.id} onClick={()=>{setActiveRoom(room.id);if(isMobile)setShowSidebar(false);}} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:10,cursor:"pointer",marginBottom:2,background:isActive?C.accentDim:"transparent",border:isActive?`1px solid ${C.accent}44`:"1px solid transparent",transition:"all .15s"}}
                onMouseEnter={e=>!isActive&&(e.currentTarget.style.background=C.card)}
                onMouseLeave={e=>!isActive&&(e.currentTarget.style.background="transparent")}
              >
                <div style={{fontSize:18}}>{room.icon}</div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontWeight:600,fontSize:13}}>{room.name}</div>
                  {last && <div style={{fontSize:11,color:C.textMuted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{last.voice?"🎤 Voice":last.text?.slice(0,28)}</div>}
                </div>
                <span style={{fontSize:10,color:C.textMuted}}>{msgs.length}</span>
              </div>
            );
          }) : (
            <>
              <input value={dmSearch} onChange={e=>setDmSearch(e.target.value)} placeholder="Search users…" style={{width:"100%",padding:"7px 10px",borderRadius:8,marginBottom:6,background:C.card,border:`1px solid ${C.border}`,color:C.text,fontSize:12,outline:"none",fontFamily:FONT}}/>
              {filteredDMs.length===0 && <div style={{textAlign:"center",color:C.textMuted,fontSize:13,padding:"20px 0"}}>No users yet</div>}
              {filteredDMs.map(u => {
                const key = dmKey(user?.username, u.username);
                const msgs = (allMsgs[key]||[]).filter(m=>!m.deleted);
                const last = msgs.slice(-1)[0];
                const isOnline = onlineNow.some(o=>o.name===u.username);
                const isActive = activeDM===u.username && activeTab==="dms";
                return (
                  <div key={u.username} onClick={()=>{setActiveDM(u.username);if(isMobile)setShowSidebar(false);}} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:10,cursor:"pointer",marginBottom:2,background:isActive?C.accentDim:"transparent",border:isActive?`1px solid ${C.accent}44`:"1px solid transparent",transition:"all .15s"}}
                    onMouseEnter={e=>!isActive&&(e.currentTarget.style.background=C.card)}
                    onMouseLeave={e=>!isActive&&(e.currentTarget.style.background="transparent")}
                  >
                    <Avatar name={u.username} size={32} online={isOnline} isAdmin={u.isAdmin}/>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontWeight:600,fontSize:13}}>{u.username}</div>
                      <div style={{fontSize:11,color:isOnline?C.online:C.textMuted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                        {isOnline?"Online":"Offline"}{last?` · ${last.voice?"🎤":last.text?.slice(0,16)}`:""}
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
        <div style={{padding:"10px 12px",borderTop:`1px solid ${C.border}`}}>
          <div style={{fontSize:11,color:C.textMuted,marginBottom:6}}>🟢 {onlineNow.length} online</div>
          <button onClick={logout} style={{width:"100%",padding:"8px",borderRadius:8,border:`1px solid ${C.danger}44`,background:C.danger+"22",color:C.danger,fontSize:12,cursor:"pointer"}}>🚪 Logout</button>
        </div>
      </div>

      {/* Main */}
      <div className="main" style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
        {/* Header */}
        <div style={{padding:"12px 16px",background:C.surface,borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
          {isMobile && (
            <button onClick={()=>setShowSidebar(true)} style={{background:"none",border:"none",color:C.text,fontSize:20,cursor:"pointer",padding:"0 4px"}}>☰</button>
          )}
          {activeTab==="dms"&&activeDM ? (
            <>
              <Avatar name={activeDM} size={32} online={onlineNow.some(u=>u.name===activeDM)} isAdmin={allUsers.find(u=>u.username===activeDM)?.isAdmin}/>
              <div>
                <div style={{fontFamily:"'Space Grotesk',sans-serif",fontWeight:600,fontSize:14}}>{activeDM}</div>
                <div style={{fontSize:11,color:onlineNow.some(u=>u.name===activeDM)?C.online:C.textMuted}}>{onlineNow.some(u=>u.name===activeDM)?"● Online":"Offline"}</div>
              </div>
            </>
          ) : (
            <>
              <div style={{fontSize:18}}>{ROOMS.find(r=>r.id===activeRoom)?.icon}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontFamily:"'Space Grotesk',sans-serif",fontWeight:600,fontSize:14}}>{ROOMS.find(r=>r.id===activeRoom)?.name}</div>
                <div style={{fontSize:11,color:C.textMuted}}>{onlineNow.length} online</div>
              </div>
              {!isMobile && (
                <div style={{display:"flex",gap:3}}>
                  {onlineNow.slice(0,5).map(u=><Avatar key={u.name} name={u.name} size={22} online/>)}
                  {onlineNow.length>5&&<div style={{fontSize:10,color:C.textMuted,alignSelf:"center"}}>+{onlineNow.length-5}</div>}
                </div>
              )}
            </>
          )}
        </div>

        {/* Messages */}
        <div style={{flex:1,overflowY:"auto",padding:"14px 14px",display:"flex",flexDirection:"column"}} onClick={()=>setEmojiFor(null)}>
          {activeTab==="dms"&&!activeDM ? (
            <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:10,opacity:.5}}>
              <div style={{fontSize:40}}>💬</div>
              <div style={{color:C.textMuted,textAlign:"center"}}>Select a user to start a private DM</div>
            </div>
          ) : curMsgs.length===0 ? (
            <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:10,opacity:.5}}>
              <div style={{fontSize:40}}>💬</div>
              <div style={{color:C.textMuted}}>No messages yet. Say hi!</div>
            </div>
          ) : curMsgs.map((msg, i) => {
            const isMine = msg.sender === user?.username;
            const senderInfo = allUsers.find(u=>u.username===msg.sender);
            const showDate = i===0 || new Date(msg.ts).toDateString()!==new Date(curMsgs[i-1]?.ts).toDateString();
            return (
              <div key={msg.id}>
                {showDate && (
                  <div style={{textAlign:"center",margin:"10px 0",fontSize:11,color:C.textMuted}}>
                    <span style={{background:C.card,padding:"3px 10px",borderRadius:10,border:`1px solid ${C.border}`}}>{new Date(msg.ts).toLocaleDateString()}</span>
                  </div>
                )}
                {msg.deleted ? (
                  <div style={{display:"flex",justifyContent:isMine?"flex-end":"flex-start",marginBottom:3}}>
                    <div style={{fontSize:12,color:C.textMuted,fontStyle:"italic",padding:"5px 10px"}}>🚫 Message deleted</div>
                  </div>
                ) : (
                  <div className="msg-wrap fadeUp" style={{display:"flex",flexDirection:"column",alignItems:isMine?"flex-end":"flex-start",marginBottom:4,position:"relative"}}>
                    {!isMine && (
                      <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:2,marginLeft:2}}>
                        <Avatar name={msg.sender} size={14} isAdmin={senderInfo?.isAdmin}/>
                        <span style={{fontSize:11,color:senderInfo?.isAdmin?C.admin:C.textMuted,fontWeight:senderInfo?.isAdmin?700:400}}>{msg.sender}{senderInfo?.isAdmin?" ⭐":""}</span>
                      </div>
                    )}
                    <div style={{display:"flex",alignItems:"flex-end",gap:5,flexDirection:isMine?"row-reverse":"row"}}>
                      <div style={{position:"relative",maxWidth:isMobile?"85vw":"460px"}}>
                        <div onDoubleClick={e=>{e.stopPropagation();setEmojiFor(emojiFor===msg.id?null:msg.id);}} style={{padding:"9px 13px",background:isMine?C.sent:C.received,borderRadius:isMine?"16px 16px 4px 16px":"16px 16px 16px 4px",border:isMine?`1px solid ${C.accent}33`:`1px solid ${C.border}`,fontSize:14,lineHeight:1.5,wordBreak:"break-word",cursor:"default"}}>
                          {editId===msg.id ? (
                            <div style={{display:"flex",gap:5}}>
                              <input value={editText} onChange={e=>setEditText(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")saveEdit(msg.id);if(e.key==="Escape")setEditId(null);}} autoFocus style={{background:"transparent",border:`1px solid ${C.accent}`,borderRadius:6,color:C.text,padding:"2px 6px",fontSize:14,outline:"none",fontFamily:FONT,minWidth:100}}/>
                              <button onClick={()=>saveEdit(msg.id)} style={{padding:"2px 7px",borderRadius:5,border:"none",background:C.accent,color:"#fff",cursor:"pointer",fontSize:12}}>✓</button>
                              <button onClick={()=>setEditId(null)} style={{padding:"2px 7px",borderRadius:5,border:"none",background:C.card,color:C.text,cursor:"pointer",fontSize:12}}>✕</button>
                            </div>
                          ) : msg.voice ? <VoicePlayer src={msg.voice}/> : (
                            <span>{msg.text}{msg.edited&&<span style={{fontSize:10,color:C.textMuted,marginLeft:5}}>(edited)</span>}</span>
                          )}
                        </div>
                        {Object.keys(msg.reactions||{}).length>0 && (
                          <div style={{display:"flex",flexWrap:"wrap",gap:3,marginTop:4,justifyContent:isMine?"flex-end":"flex-start"}}>
                            {Object.entries(msg.reactions).map(([emoji,users])=>(
                              <div key={emoji} onClick={e=>{e.stopPropagation();addReaction(msg.id,emoji);}} style={{padding:"2px 6px",borderRadius:10,background:C.card,border:`1px solid ${users.includes(user?.username)?C.accent:C.border}`,fontSize:12,cursor:"pointer",display:"flex",alignItems:"center",gap:2}}>
                                {emoji}<span style={{fontSize:10,color:C.textMuted}}>{users.length}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {emojiFor===msg.id && (
                          <div onClick={e=>e.stopPropagation()} style={{position:"absolute",bottom:"calc(100% + 6px)",[isMine?"right":"left"]:0,background:C.surface,border:`1px solid ${C.border}`,borderRadius:12,padding:8,display:"flex",gap:3,boxShadow:"0 8px 24px rgba(0,0,0,.4)",zIndex:100,flexWrap:"wrap",maxWidth:220}}>
                            {EMOJIS.map(e=>(
                              <button key={e} onClick={()=>addReaction(msg.id,e)} style={{background:"none",border:"none",fontSize:18,cursor:"pointer",padding:"3px 4px",borderRadius:6}} onMouseEnter={ev=>ev.target.style.background=C.card} onMouseLeave={ev=>ev.target.style.background="none"}>{e}</button>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="hover-actions" style={{display:"flex",flexDirection:"column",gap:3}}>
                        <button onClick={e=>{e.stopPropagation();setEmojiFor(emojiFor===msg.id?null:msg.id);}} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:6,color:C.textMuted,fontSize:11,cursor:"pointer",padding:"3px 5px"}}>😊</button>
                        {isMine&&!msg.voice&&(<button onClick={()=>{setEditId(msg.id);setEditText(msg.text||"");}} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:6,color:C.textMuted,fontSize:11,cursor:"pointer",padding:"3px 5px"}}>✏️</button>)}
                        {(isMine||user?.isAdmin)&&(<button onClick={()=>deleteMsg(msg.id)} style={{background:C.danger+"22",border:`1px solid ${C.danger}44`,borderRadius:6,color:C.danger,fontSize:11,cursor:"pointer",padding:"3px 5px"}}>🗑</button>)}
                      </div>
                    </div>
                    <span style={{fontSize:10,color:C.textMuted,marginTop:2,marginLeft:2,marginRight:2}}>
                      {new Date(msg.ts).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}{isMine&&" ✓✓"}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
          <div ref={endRef}/>
        </div>

        {/* Input */}
        {(activeTab==="rooms"||(activeTab==="dms"&&activeDM)) && (
          <div style={{padding:"10px 14px",background:C.surface,borderTop:`1px solid ${C.border}`,flexShrink:0}}>
            <div style={{display:"flex",gap:6,alignItems:"flex-end",background:C.card,borderRadius:14,border:`1px solid ${C.border}`,padding:"3px 3px 3px 12px"}}>
              <textarea ref={inputRef} value={input}
                onChange={e=>setInput(e.target.value)}
                onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg();}}}
                placeholder={`Message ${activeTab==="dms"&&activeDM?activeDM:ROOMS.find(r=>r.id===activeRoom)?.name||""}…`}
                rows={1} style={{flex:1,background:"transparent",border:"none",outline:"none",color:C.text,fontSize:14,fontFamily:FONT,resize:"none",lineHeight:1.5,padding:"10px 0",maxHeight:100,overflowY:"auto"}}
              />
              <button onMouseDown={startRec} onMouseUp={stopRec} onMouseLeave={()=>recording&&stopRec()} onTouchStart={startRec} onTouchEnd={stopRec}
                style={{width:38,height:38,borderRadius:9,flexShrink:0,background:recording?C.danger:C.card,border:`1px solid ${recording?C.danger:C.border}`,color:recording?"#fff":C.textMuted,cursor:"pointer",fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",animation:recording?"recPulse 1s infinite":"none"}}>
                {recording?`${secs}s`:"🎤"}
              </button>
              <button onClick={()=>sendMsg()} disabled={!input.trim()} style={{width:38,height:38,borderRadius:9,flexShrink:0,background:input.trim()?C.accent:C.border,border:"none",color:"#fff",fontSize:17,cursor:input.trim()?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s"}}>↑</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
