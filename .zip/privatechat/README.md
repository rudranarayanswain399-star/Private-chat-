# 🔐 PrivateChat

A secure, private, real-time chat app with password encryption, admin panel, DMs, voice messages, and emoji reactions.

## Features
- 🔒 SHA-256 password encryption
- 🛡️ Admin panel (first account = admin)
- 💬 Private DMs between users
- 🎤 Voice messages
- 😊 Emoji reactions
- ✏️ Edit & delete messages
- 📱 Mobile responsive

---

## 🚀 Deploy FREE in 5 minutes (Vercel)

### Step 1: Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2: Create a GitHub account
Go to https://github.com and sign up (free)

### Step 3: Upload this project to GitHub
1. Go to https://github.com/new
2. Name it `privatechat`
3. Click "Create repository"
4. Upload all these files by dragging them in

### Step 4: Deploy on Vercel
1. Go to https://vercel.com and sign up with GitHub
2. Click **"New Project"**
3. Select your `privatechat` repository
4. Click **"Deploy"**
5. Done! You'll get a link like: `https://privatechat-xyz.vercel.app`

---

## 🚀 Deploy FREE on Netlify (Alternative)

1. Go to https://netlify.com
2. Drag and drop the entire project folder
3. Or connect your GitHub repo
4. Get a link like: `https://privatechat.netlify.app`

---

## Run Locally

```bash
npm install
npm start
```

Open http://localhost:3000

---

## ⚠️ Important Notes

- **First registered account is automatically Admin**
- Messages are stored in **localStorage** — they stay on each device
- For a shared database across all devices, you'd need a backend (Firebase, Supabase, etc.)
- To reset and become admin: open browser console and type `localStorage.clear()`

---

## 📁 File Structure

```
privatechat/
├── public/
│   └── index.html
├── src/
│   ├── App.jsx      ← Main app
│   └── index.js     ← Entry point
├── package.json
└── README.md
```
