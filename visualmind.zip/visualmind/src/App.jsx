import { useState, useEffect, useRef } from "react";

const PERSONALITIES = [
  { id: "vision", name: "VisionAI", emoji: "🔬", color: "#00d4ff", desc: "Detailed & Scientific", system: "You are VisionAI, a highly detailed scientific image analyst. Describe images with extreme precision, noting colors, shapes, composition, lighting, objects, text, people, emotions, and any technical details. Be thorough and analytical." },
  { id: "poet", name: "Muse", emoji: "🎨", color: "#ff6b9d", desc: "Creative & Poetic", system: "You are Muse, a creative and poetic AI. Describe images beautifully with metaphors, emotions, and artistic language. Paint a picture with your words. Be expressive, imaginative, and inspiring." },
  { id: "detective", name: "Detective", emoji: "🕵️", color: "#ffd700", desc: "Investigative & Sharp", system: "You are Detective AI. Analyze images like a detective — notice every detail, look for clues, identify what's unusual, spot hidden elements, deduce context and story behind the image. Be sharp, observant, and investigative." },
  { id: "funny", name: "Roaster", emoji: "😂", color: "#ff4500", desc: "Funny & Sarcastic", system: "You are Roaster AI, a funny and witty image commentator. Describe images with humor, jokes, and playful sarcasm. Make it entertaining! Keep it fun but not mean-spirited." },
  { id: "teacher", name: "Professor", emoji: "📚", color: "#4caf50", desc: "Educational & Insightful", system: "You are Professor AI, an educational image analyst. Explain what's in the image, provide context, historical background if relevant, educational insights, and what people can learn from it. Be informative and enlightening." },
];

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
html,body,#root{height:100%}
body{background:#08090f;font-family:'DM Mono',monospace;color:#e8edf5;overflow:hidden}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:#1e2d42;border-radius:2px}
@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@keyframes scanline{0%{top:-10%}100%{top:110%}}
@keyframes glow{0%,100%{box-shadow:0 0 20px rgba(0,212,255,0.3)}50%{box-shadow:0 0 40px rgba(0,212,255,0.6)}}
@keyframes ripple{0%{transform:scale(1);opacity:1}100%{transform:scale(2);opacity:0}}
.fadeUp{animation:fadeUp 0.3s ease forwards}
.scanning::after{content:'';position:absolute;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,#00d4ff,transparent);animation:scanline 2s linear infinite;pointer-events:none}
.pulse{animation:pulse 1.5s ease-in-out infinite}
.spin{animation:spin 1s linear infinite}
`;

function LoadingDots() {
  return (
    <div style={{display:"flex",gap:6,alignItems:"center",padding:"4px 0"}}>
      {[0,1,2].map(i=>(
        <div key={i} style={{width:8,height:8,borderRadius:"50%",background:"#00d4ff",animation:`pulse 1.2s ease-in-out ${i*0.2}s infinite`}}/>
      ))}
    </div>
  );
}

function WaveVisualizer({active}) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:3,height:24}}>
      {[...Array(12)].map((_,i)=>(
        <div key={i} style={{
          width:3,borderRadius:2,
          background:"#00d4ff",
          height: active ? `${Math.random()*20+4}px` : "4px",
          transition:"height 0.15s ease",
          animation: active ? `pulse ${0.5+Math.random()*0.5}s ease-in-out ${i*0.05}s infinite` : "none",
        }}/>
      ))}
    </div>
  );
}

export default function App() {
  const [personality, setPersonality] = useState(PERSONALITIES[0]);
  const [image, setImage] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [savedConvos, setSavedConvos] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [tab, setTab] = useState("analyze"); // analyze | saved | search
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [toast, setToast] = useState(null);
  const fileRef = useRef(null);
  const endRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const s = document.createElement("style");
    s.textContent = CSS;
    document.head.appendChild(s);
    // Load saved conversations
    try {
      const saved = JSON.parse(localStorage.getItem("ai_saved_convos") || "[]");
      setSavedConvos(saved);
    } catch {}
    return () => document.head.removeChild(s);
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({behavior:"smooth"}); }, [conversations, loading]);

  const showToast = (msg, color="#00d4ff") => {
    setToast({msg, color});
    setTimeout(() => setToast(null), 3000);
  };

  const handleImage = (file) => {
    if (!file || !file.type.startsWith("image/")) return showToast("Please upload an image file", "#ff4757");
    const reader = new FileReader();
    reader.onload = (e) => {
      setImage(e.target.result);
      setImageBase64(e.target.result.split(",")[1]);
      setConversations([]);
      showToast("Image loaded! Click Analyze 🔬");
    };
    reader.readAsDataURL(file);
  };

  const analyzeImage = async (customPrompt) => {
    if (!imageBase64) return showToast("Please upload an image first!", "#ff4757");
    const prompt = customPrompt || "Analyze this image in detail.";
    const userMsg = {role:"user", text: prompt, ts: Date.now()};
    setConversations(p => [...p, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const messages = [
        ...conversations.map(c => ({
          role: c.role,
          content: c.role === "user" && c === conversations[0]
            ? [{type:"image",source:{type:"base64",media_type:"image/jpeg",data:imageBase64}},{type:"text",text:c.text}]
            : c.text
        })),
        {
          role: "user",
          content: conversations.length === 0
            ? [{type:"image",source:{type:"base64",media_type:"image/jpeg",data:imageBase64}},{type:"text",text:prompt}]
            : prompt
        }
      ];

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          system: personality.system,
          messages,
        })
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "Could not analyze image.";
      setConversations(p => [...p, {role:"assistant", text, ts:Date.now(), personality: personality.id}]);
    } catch(e) {
      setConversations(p => [...p, {role:"assistant", text:"Error analyzing image. Please try again.", ts:Date.now()}]);
    }
    setLoading(false);
  };

  const webSearch = async () => {
    if (!searchQuery.trim()) return;
    setSearchLoading(true);
    setSearchResults(null);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          tools:[{type:"web_search_20250305",name:"web_search"}],
          messages:[{role:"user",content:`Search the web and answer this question with current information: ${searchQuery}`}]
        })
      });
      const data = await res.json();
      const text = data.content?.filter(c=>c.type==="text").map(c=>c.text).join("\n") || "No results found.";
      setSearchResults(text);
    } catch {
      setSearchResults("Search failed. Please try again.");
    }
    setSearchLoading(false);
  };

  const saveConversation = () => {
    if (!conversations.length) return showToast("Nothing to save!", "#ff4757");
    const convo = {
      id: Date.now(),
      image: image,
      personality: personality.name,
      messages: conversations,
      savedAt: new Date().toLocaleString(),
      title: conversations[0]?.text?.slice(0,40) || "Untitled"
    };
    const updated = [convo, ...savedConvos].slice(0,20);
    setSavedConvos(updated);
    localStorage.setItem("ai_saved_convos", JSON.stringify(updated));
    showToast("Conversation saved! 💾");
  };

  const startVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return showToast("Voice not supported on this browser", "#ff4757");
    const recognition = new SR();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => setListening(true);
    recognition.onresult = (e) => { setInput(e.results[0][0].transcript); setListening(false); };
    recognition.onerror = () => { setListening(false); showToast("Voice error, try again", "#ff4757"); };
    recognition.onend = () => setListening(false);
    recognition.start();
    recognitionRef.current = recognition;
  };

  const speak = (text) => {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 1; utter.pitch = 1;
    window.speechSynthesis.speak(utter);
  };

  const P = personality;

  return (
    <div style={{height:"100%",display:"flex",background:"#08090f",overflow:"hidden",position:"relative"}}>

      {/* Toast */}
      {toast && (
        <div style={{position:"fixed",top:20,left:"50%",transform:"translateX(-50%)",background:toast.color,color:"#000",padding:"10px 20px",borderRadius:20,fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:13,zIndex:999,boxShadow:"0 8px 32px rgba(0,0,0,.5)"}}>
          {toast.msg}
        </div>
      )}

      {/* Sidebar */}
      <div style={{width:220,background:"#0d0f1a",borderRight:"1px solid #1a2235",display:"flex",flexDirection:"column",flexShrink:0}}>
        {/* Logo */}
        <div style={{padding:"20px 16px",borderBottom:"1px solid #1a2235"}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:18,background:`linear-gradient(135deg, ${P.color}, #fff)`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
            VisualMind
          </div>
          <div style={{fontSize:10,color:"#8899aa",marginTop:2}}>AI Image Intelligence</div>
        </div>

        {/* Tabs */}
        <div style={{padding:"10px 8px",borderBottom:"1px solid #1a2235"}}>
          {[["analyze","🔬","Analyze"],["saved","💾","Saved"],["search","🌐","Web Search"]].map(([t,icon,label])=>(
            <div key={t} onClick={()=>setTab(t)} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:8,cursor:"pointer",marginBottom:2,background:tab===t?`${P.color}22`:"transparent",color:tab===t?P.color:"#8899aa",border:tab===t?`1px solid ${P.color}44`:"1px solid transparent",transition:"all .15s",fontSize:13}}>
              <span>{icon}</span><span style={{fontWeight:tab===t?600:400}}>{label}</span>
            </div>
          ))}
        </div>

        {/* Personalities */}
        <div style={{padding:"10px 8px",flex:1,overflowY:"auto"}}>
          <div style={{fontSize:10,color:"#8899aa",textTransform:"uppercase",letterSpacing:1,padding:"0 6px",marginBottom:8}}>AI Personality</div>
          {PERSONALITIES.map(p=>(
            <div key={p.id} onClick={()=>setPersonality(p)} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:8,cursor:"pointer",marginBottom:4,background:personality.id===p.id?`${p.color}22`:"transparent",border:personality.id===p.id?`1px solid ${p.color}55`:"1px solid transparent",transition:"all .15s"}}>
              <span style={{fontSize:18}}>{p.emoji}</span>
              <div>
                <div style={{fontSize:12,fontWeight:600,color:personality.id===p.id?p.color:"#e8edf5"}}>{p.name}</div>
                <div style={{fontSize:10,color:"#8899aa"}}>{p.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Save button */}
        {tab==="analyze" && conversations.length>0 && (
          <div style={{padding:"10px 10px",borderTop:"1px solid #1a2235"}}>
            <button onClick={saveConversation} style={{width:"100%",padding:"9px",borderRadius:8,border:`1px solid ${P.color}55`,background:`${P.color}22`,color:P.color,fontSize:12,cursor:"pointer",fontFamily:"'DM Mono',monospace",fontWeight:500}}>
              💾 Save Conversation
            </button>
          </div>
        )}
      </div>

      {/* Main */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>

        {/* ── ANALYZE TAB ── */}
        {tab==="analyze" && (
          <>
            {/* Header */}
            <div style={{padding:"14px 20px",background:"#0d0f1a",borderBottom:"1px solid #1a2235",display:"flex",alignItems:"center",gap:12}}>
              <div style={{fontSize:22}}>{P.emoji}</div>
              <div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,color:P.color}}>{P.name}</div>
                <div style={{fontSize:11,color:"#8899aa"}}>{P.desc}</div>
              </div>
              <div style={{flex:1}}/>
              {image && (
                <button onClick={()=>{setImage(null);setImageBase64(null);setConversations([]);}} style={{padding:"6px 12px",borderRadius:8,border:"1px solid #ff475744",background:"#ff475722",color:"#ff4757",fontSize:12,cursor:"pointer"}}>
                  Clear Image
                </button>
              )}
            </div>

            <div style={{flex:1,display:"flex",overflow:"hidden"}}>
              {/* Left: Image upload */}
              <div style={{width:280,borderRight:"1px solid #1a2235",display:"flex",flexDirection:"column",gap:0,flexShrink:0}}>
                {/* Upload zone */}
                <div
                  onDragOver={e=>{e.preventDefault();setDragOver(true);}}
                  onDragLeave={()=>setDragOver(false)}
                  onDrop={e=>{e.preventDefault();setDragOver(false);handleImage(e.dataTransfer.files[0]);}}
                  onClick={()=>fileRef.current?.click()}
                  style={{
                    margin:12, borderRadius:12, border:`2px dashed ${dragOver?P.color:"#1e2d42"}`,
                    background:dragOver?`${P.color}11`:"#0d0f1a",
                    cursor:"pointer", transition:"all .2s", overflow:"hidden",
                    aspectRatio:"1", display:"flex", alignItems:"center", justifyContent:"center",
                    position:"relative",
                  }}
                  className={image?"scanning":""}
                >
                  {image ? (
                    <img src={image} alt="uploaded" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:10}}/>
                  ) : (
                    <div style={{textAlign:"center",padding:20}}>
                      <div style={{fontSize:36,marginBottom:8}}>🖼️</div>
                      <div style={{fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:13,color:P.color}}>Drop image here</div>
                      <div style={{fontSize:11,color:"#8899aa",marginTop:4}}>or click to browse</div>
                    </div>
                  )}
                </div>
                <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>handleImage(e.target.files[0])}/>

                {/* Quick analyze buttons */}
                {image && (
                  <div style={{padding:"0 12px 12px",display:"flex",flexDirection:"column",gap:6}}>
                    {["Describe everything in detail","What emotions does this convey?","What's interesting or unusual?","Identify all objects & people"].map(q=>(
                      <button key={q} onClick={()=>analyzeImage(q)} style={{padding:"8px 10px",borderRadius:8,border:`1px solid ${P.color}33`,background:`${P.color}11`,color:"#e8edf5",fontSize:11,cursor:"pointer",textAlign:"left",fontFamily:"'DM Mono',monospace",transition:"all .15s"}}
                        onMouseEnter={e=>e.currentTarget.style.background=`${P.color}22`}
                        onMouseLeave={e=>e.currentTarget.style.background=`${P.color}11`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right: Conversation */}
              <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
                <div style={{flex:1,overflowY:"auto",padding:"16px 20px"}}>
                  {conversations.length===0 && !loading && (
                    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:12,opacity:.5}}>
                      <div style={{fontSize:48}}>{P.emoji}</div>
                      <div style={{fontFamily:"'Syne',sans-serif",fontSize:16,fontWeight:700,color:P.color}}>{P.name}</div>
                      <div style={{fontSize:13,color:"#8899aa",textAlign:"center"}}>{image?"Click a quick button or ask anything about the image":"Upload an image to get started"}</div>
                    </div>
                  )}
                  {conversations.map((msg,i)=>{
                    const isMine = msg.role==="user";
                    const msgPersonality = PERSONALITIES.find(p=>p.id===msg.personality);
                    return(
                      <div key={i} className="fadeUp" style={{display:"flex",flexDirection:"column",alignItems:isMine?"flex-end":"flex-start",marginBottom:14}}>
                        {!isMine && (
                          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
                            <span style={{fontSize:14}}>{msgPersonality?.emoji||P.emoji}</span>
                            <span style={{fontSize:11,color:msgPersonality?.color||P.color,fontWeight:600}}>{msgPersonality?.name||P.name}</span>
                          </div>
                        )}
                        <div style={{
                          maxWidth:"85%", padding:"12px 16px",
                          background:isMine?"#1a1040":`${(msgPersonality?.color||P.color)}11`,
                          borderRadius:isMine?"16px 16px 4px 16px":"16px 16px 16px 4px",
                          border:isMine?"1px solid #6c63ff33":`1px solid ${(msgPersonality?.color||P.color)}33`,
                          fontSize:13, lineHeight:1.7, whiteSpace:"pre-wrap",
                        }}>
                          {msg.text}
                        </div>
                        {!isMine && (
                          <button onClick={()=>speak(msg.text)} style={{marginTop:4,background:"none",border:"none",color:"#8899aa",fontSize:11,cursor:"pointer",padding:"2px 4px"}}>
                            🔊 Listen
                          </button>
                        )}
                      </div>
                    );
                  })}
                  {loading && (
                    <div style={{display:"flex",alignItems:"center",gap:10,padding:"12px 16px",background:`${P.color}11`,borderRadius:"16px 16px 16px 4px",border:`1px solid ${P.color}33`,width:"fit-content",marginBottom:14}}>
                      <span style={{fontSize:16}}>{P.emoji}</span>
                      <LoadingDots/>
                      <span style={{fontSize:11,color:"#8899aa"}}>Analyzing...</span>
                    </div>
                  )}
                  <div ref={endRef}/>
                </div>

                {/* Input */}
                <div style={{padding:"12px 16px",borderTop:"1px solid #1a2235",background:"#0d0f1a"}}>
                  <div style={{display:"flex",gap:8,alignItems:"flex-end",background:"#161e2e",borderRadius:14,border:`1px solid ${P.color}33`,padding:"4px 4px 4px 14px"}}>
                    <textarea value={input} onChange={e=>setInput(e.target.value)}
                      onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();analyzeImage(input);}}}
                      placeholder={image?"Ask anything about this image...":"Upload an image first..."}
                      rows={1} disabled={!image}
                      style={{flex:1,background:"transparent",border:"none",outline:"none",color:"#e8edf5",fontSize:13,fontFamily:"'DM Mono',monospace",resize:"none",lineHeight:1.5,padding:"10px 0",maxHeight:80,overflowY:"auto"}}
                    />
                    <button onClick={startVoice} style={{width:38,height:38,borderRadius:9,background:listening?`${P.color}44`:"#1a2235",border:`1px solid ${listening?P.color:"#1e2d42"}`,color:listening?P.color:"#8899aa",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                      {listening ? <WaveVisualizer active={true}/> : "🎤"}
                    </button>
                    <button onClick={()=>analyzeImage(input)} disabled={!image||!input.trim()} style={{width:38,height:38,borderRadius:9,background:image&&input.trim()?P.color:"#1a2235",border:"none",color:"#fff",fontSize:16,cursor:image&&input.trim()?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .2s"}}>↑</button>
                  </div>
                  <div style={{fontSize:10,color:"#8899aa",textAlign:"center",marginTop:5}}>
                    🎤 voice input · 🔊 listen to response · Enter to send
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* ── SAVED TAB ── */}
        {tab==="saved" && (
          <div style={{flex:1,overflowY:"auto",padding:20}}>
            <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:20,marginBottom:16}}>💾 Saved Conversations</div>
            {savedConvos.length===0 ? (
              <div style={{textAlign:"center",opacity:.5,padding:"60px 0"}}>
                <div style={{fontSize:40,marginBottom:8}}>📭</div>
                <div style={{color:"#8899aa"}}>No saved conversations yet</div>
              </div>
            ) : savedConvos.map(convo=>(
              <div key={convo.id} style={{background:"#0d0f1a",borderRadius:14,border:"1px solid #1a2235",padding:16,marginBottom:12}}>
                <div style={{display:"flex",gap:12,marginBottom:12}}>
                  {convo.image && <img src={convo.image} alt="" style={{width:60,height:60,borderRadius:8,objectFit:"cover",border:"1px solid #1a2235"}}/>}
                  <div style={{flex:1}}>
                    <div style={{fontWeight:600,fontSize:14,marginBottom:2}}>{convo.title}...</div>
                    <div style={{fontSize:11,color:"#8899aa"}}>{convo.personality} · {convo.savedAt}</div>
                    <div style={{fontSize:11,color:"#8899aa"}}>{convo.messages.length} messages</div>
                  </div>
                  <button onClick={()=>{setSavedConvos(p=>{const u=p.filter(c=>c.id!==convo.id);localStorage.setItem("ai_saved_convos",JSON.stringify(u));return u;});}} style={{background:"#ff475722",border:"1px solid #ff475744",borderRadius:8,color:"#ff4757",fontSize:12,cursor:"pointer",padding:"4px 10px",height:"fit-content"}}>🗑</button>
                </div>
                <div style={{maxHeight:120,overflowY:"auto",borderTop:"1px solid #1a2235",paddingTop:10}}>
                  {convo.messages.slice(0,3).map((m,i)=>(
                    <div key={i} style={{fontSize:12,color:m.role==="user"?"#8899aa":"#e8edf5",marginBottom:4,lineHeight:1.5}}>
                      <span style={{color:m.role==="user"?"#6c63ff":"#00d4ff",marginRight:6}}>{m.role==="user"?"You:":"AI:"}</span>
                      {m.text.slice(0,100)}{m.text.length>100?"...":""}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── SEARCH TAB ── */}
        {tab==="search" && (
          <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
            <div style={{padding:"16px 20px",borderBottom:"1px solid #1a2235",background:"#0d0f1a"}}>
              <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:18,marginBottom:12}}>🌐 Web Search</div>
              <div style={{display:"flex",gap:8}}>
                <input value={searchQuery} onChange={e=>setSearchQuery(e.target.value)}
                  onKeyDown={e=>e.key==="Enter"&&webSearch()}
                  placeholder="Search anything on the internet..."
                  style={{flex:1,padding:"12px 16px",borderRadius:10,background:"#161e2e",border:"1px solid #1e2d42",color:"#e8edf5",fontSize:13,outline:"none",fontFamily:"'DM Mono',monospace"}}
                />
                <button onClick={webSearch} disabled={!searchQuery.trim()||searchLoading} style={{padding:"12px 20px",borderRadius:10,background:searchQuery.trim()?P.color:"#1a2235",border:"none",color:"#fff",fontSize:14,cursor:searchQuery.trim()?"pointer":"default",fontFamily:"'DM Mono',monospace",transition:"all .2s"}}>
                  {searchLoading?"⟳":"Search"}
                </button>
              </div>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:20}}>
              {searchLoading && (
                <div style={{display:"flex",alignItems:"center",gap:10,color:"#8899aa"}}>
                  <div className="spin" style={{fontSize:20}}>⟳</div>
                  Searching the web...
                </div>
              )}
              {searchResults && (
                <div className="fadeUp" style={{background:"#0d0f1a",borderRadius:14,border:`1px solid ${P.color}33`,padding:20}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
                    <span style={{fontSize:16}}>🌐</span>
                    <span style={{fontFamily:"'Syne',sans-serif",fontWeight:700,color:P.color}}>Search Results</span>
                    <button onClick={()=>speak(searchResults)} style={{marginLeft:"auto",background:"none",border:"none",color:"#8899aa",fontSize:12,cursor:"pointer"}}>🔊 Listen</button>
                  </div>
                  <div style={{fontSize:13,lineHeight:1.8,whiteSpace:"pre-wrap",color:"#e8edf5"}}>{searchResults}</div>
                </div>
              )}
              {!searchResults && !searchLoading && (
                <div style={{textAlign:"center",opacity:.5,padding:"60px 0"}}>
                  <div style={{fontSize:40,marginBottom:8}}>🌐</div>
                  <div style={{color:"#8899aa"}}>Search anything — current news, facts, anything!</div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
